
import './App.css';
import {Routes, Route} from 'react-router-dom'
import Contact from './Component/Contact';
import Home from './Component/Home';
import Login from './Component/Login';
import Navbar from './Component/Navbar';
import Frontend from './Component/Frontend';
import Backend from './Component/Backend';

function App() {
  return (
    <div>
        <Navbar />
        <Routes>
          <Route path='/' element ={<Home/>} />
          <Route path='/contact' element ={<Contact/>}>
              <Route path='frontend' element={<Frontend/>} />
              <Route path='backend' element={<Backend/>} />
          </Route>
          <Route path='/login' element ={<Login/>} />
        </Routes>
    </div>
  );
}

export default App;
