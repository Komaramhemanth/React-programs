import React from 'react'
import { Link, Outlet } from 'react-router-dom'
import './contact.css'
export default function Contact() {


  return (
    <div>
        <div>
            <ul>
                <li><Link className ="abc" to='/contact/frontend'>Frontend</Link></li>
                <li><Link className ="abc" to='/contact/backend'>Backend</Link></li>
            </ul>
        </div>
        <div>
            <Outlet />
        </div>
    </div>
  )
}
