import React from 'react'
import Button from '@mui/material/Button';

export default function Frontend() {
  return (
    <div>
        <Button variant="contained">Contained</Button>
        <Button variant="outlined">Outlined</Button>
    </div>
  )
}
